import 'package:flutter/material.dart';

import 'SplashScreen.dart';

void main() {
  runApp(MaterialApp(home: SplashScreen(),));
}
/*        GradientText(
          gradientType: GradientType.linear,
          gradientDirection: GradientDirection.ttb,
          colors: [Color(0xff47BFDF), Color(0xff4A91FF)],
          "Forcasting",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
        )
*/